package com.example.doctornotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
